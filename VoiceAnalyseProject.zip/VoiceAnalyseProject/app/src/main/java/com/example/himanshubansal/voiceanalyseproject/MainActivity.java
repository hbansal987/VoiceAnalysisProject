package com.example.himanshubansal.voiceanalyseproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button getStarted;
    EditText nameText;
    public static String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getStarted= findViewById(R.id.getStartedButton);
        nameText= findViewById(R.id.nameText);
        name= nameText.getText().toString();

        getStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Button Clicked", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(MainActivity.this,GetStarted.class);
                i.putExtra("Name", name);
                startActivity(i);
            }
        });

    }
}
